import React from 'react';
import { MapPin, Phone, Mail, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Hotel Info */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-amber-600 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">M</span>
              </div>
              <div>
                <span className="text-2xl font-bold">Marjan Hotel</span>
                <p className="text-xs text-gray-400">Luxury & Comfort</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Experience unparalleled luxury and authentic Kenyan hospitality in the heart of Tana River. 
              Your perfect getaway awaits at Marjan Hotel.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li><a href="#home" className="text-gray-400 hover:text-white transition-colors">Home</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#rooms" className="text-gray-400 hover:text-white transition-colors">Rooms & Suites</a></li>
              <li><a href="#restaurant" className="text-gray-400 hover:text-white transition-colors">Restaurant</a></li>
              <li><a href="#gallery" className="text-gray-400 hover:text-white transition-colors">Gallery</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Services</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Room Service</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Restaurant Dining</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Event Planning</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Tour Arrangements</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Airport Transfer</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Laundry Service</a></li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Contact Info</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-amber-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-400">Tana River County, Kenya</p>
                  <p className="text-gray-400">Along the Tana River Banks</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <a href="tel:+254725277706" className="text-gray-400 hover:text-white transition-colors">
                  +254725277706
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <a href="mailto:Marjanhotel@gmail.com" className="text-gray-400 hover:text-white transition-colors">
                  Marjanhotel@gmail.com
                </a>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-amber-600/10 rounded-lg border border-amber-600/20">
              <h4 className="text-amber-400 font-semibold mb-2">24/7 Reception</h4>
              <p className="text-sm text-gray-400">
                Our reception desk is available round the clock for your convenience.
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-center md:text-left">
              &copy; 2025 Marjan Hotel. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Cancellation Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
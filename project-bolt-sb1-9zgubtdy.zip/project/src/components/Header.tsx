import React, { useState } from 'react';
import { Menu, X, MapPin, Phone, Mail } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <>
      {/* Top Bar */}
      <div className="bg-amber-800 text-white py-2 text-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-1 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <MapPin className="w-4 h-4" />
                <span>Tana River, Kenya</span>
              </div>
              <div className="flex items-center space-x-1">
                <Phone className="w-4 h-4" />
                <span>+254725277706</span>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <Mail className="w-4 h-4" />
              <span>Marjanhotel@gmail.com</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="fixed top-8 left-0 right-0 z-50 bg-white/95 backdrop-blur-md shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-amber-600 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">M</span>
              </div>
              <div>
                <span className="text-2xl font-bold text-gray-900">Marjan Hotel</span>
                <p className="text-xs text-gray-600">Luxury & Comfort</p>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#home" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Home</a>
              <a href="#about" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">About</a>
              <a href="#rooms" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Rooms</a>
              <a href="#restaurant" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Restaurant</a>
              <a href="#gallery" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Gallery</a>
              <a href="#contact" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Contact</a>
              <button className="bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-2 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 transform hover:scale-105 font-medium">
                Book Now
              </button>
            </nav>

            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-2 space-y-2">
              <a href="#home" className="block py-2 text-gray-700 hover:text-amber-600">Home</a>
              <a href="#about" className="block py-2 text-gray-700 hover:text-amber-600">About</a>
              <a href="#rooms" className="block py-2 text-gray-700 hover:text-amber-600">Rooms</a>
              <a href="#restaurant" className="block py-2 text-gray-700 hover:text-amber-600">Restaurant</a>
              <a href="#gallery" className="block py-2 text-gray-700 hover:text-amber-600">Gallery</a>
              <a href="#contact" className="block py-2 text-gray-700 hover:text-amber-600">Contact</a>
              <button className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white px-4 py-2 rounded-lg mt-2">
                Book Now
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

export default Header;
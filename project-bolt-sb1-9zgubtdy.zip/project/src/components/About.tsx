import React from 'react';
import { Award, Heart, Leaf, Shield } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: <Award className="w-8 h-8" />,
      title: "Award Winning Service",
      description: "Recognized for excellence in hospitality and guest satisfaction"
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Authentic Kenyan Experience",
      description: "Immerse yourself in local culture and traditional hospitality"
    },
    {
      icon: <Leaf className="w-8 h-8" />,
      title: "Eco-Friendly Practices",
      description: "Committed to sustainable tourism and environmental conservation"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Safety & Security",
      description: "24/7 security and safety measures for your peace of mind"
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Discover the Magic of
              <span className="block text-amber-600">Tana River</span>
            </h2>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Nestled along the banks of the majestic Tana River, Marjan Hotel offers an 
              unparalleled blend of luxury and authentic Kenyan culture. Our hotel serves 
              as your gateway to exploring the natural beauty and rich heritage of this 
              remarkable region.
            </p>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              From our elegantly appointed rooms to our world-class restaurant featuring 
              traditional Kenyan cuisine, every aspect of your stay is designed to create 
              unforgettable memories while celebrating the warmth of Kenyan hospitality.
            </p>
            <button className="bg-gradient-to-r from-amber-600 to-orange-600 text-white px-8 py-3 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 transform hover:scale-105 font-semibold">
              Learn More About Us
            </button>
          </div>
          
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <img 
                src="https://images.pexels.com/photos/2096983/pexels-photo-2096983.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1"
                alt="Tana River landscape"
                className="rounded-lg shadow-lg"
              />
              <img 
                src="https://images.pexels.com/photos/1838554/pexels-photo-1838554.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1"
                alt="Kenyan wildlife"
                className="rounded-lg shadow-lg mt-8"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-white p-6 rounded-lg shadow-xl">
              <div className="text-3xl font-bold text-amber-600">15+</div>
              <div className="text-gray-600">Years of Excellence</div>
            </div>
          </div>
        </div>
        
        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <div className="text-amber-600 mb-4 flex justify-center">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
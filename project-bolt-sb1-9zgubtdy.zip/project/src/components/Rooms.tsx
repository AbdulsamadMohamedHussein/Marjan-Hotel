import React, { useState } from 'react';
import { Wifi, Car, Coffee, Tv, Bath, Users, Star, Calendar } from 'lucide-react';

const Rooms: React.FC = () => {
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);

  const rooms = [
    {
      id: 1,
      name: "Deluxe River View Suite",
      price: "KSh 15,000",
      image: "https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&dpr=1",
      description: "Spacious suite with panoramic views of the Tana River, featuring a private balcony and luxury amenities.",
      amenities: ["River View", "Private Balcony", "King Bed", "Mini Bar", "Free WiFi", "Air Conditioning"],
      size: "45 sqm",
      guests: 2,
      rating: 4.9
    },
    {
      id: 2,
      name: "Executive Garden Room",
      price: "KSh 12,000",
      image: "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&dpr=1",
      description: "Elegant room overlooking our tropical gardens with modern furnishings and premium comfort.",
      amenities: ["Garden View", "Queen Bed", "Work Desk", "Free WiFi", "Satellite TV", "Room Service"],
      size: "35 sqm",
      guests: 2,
      rating: 4.8
    },
    {
      id: 3,
      name: "Family Safari Suite",
      price: "KSh 20,000",
      image: "https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&dpr=1",
      description: "Perfect for families, featuring separate living area and connecting rooms with safari-themed decor.",
      amenities: ["Separate Living Area", "2 Bedrooms", "Family Bathroom", "Kitchenette", "Free WiFi", "Game Console"],
      size: "65 sqm",
      guests: 4,
      rating: 4.9
    },
    {
      id: 4,
      name: "Standard Comfort Room",
      price: "KSh 8,000",
      image: "https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&dpr=1",
      description: "Comfortable and affordable accommodation with all essential amenities for a pleasant stay.",
      amenities: ["Double Bed", "Private Bathroom", "Free WiFi", "Satellite TV", "Air Conditioning", "Daily Housekeeping"],
      size: "25 sqm",
      guests: 2,
      rating: 4.6
    }
  ];

  return (
    <section id="rooms" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Luxury Accommodations
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Choose from our carefully designed rooms and suites, each offering comfort, 
            elegance, and stunning views of the Tana River region.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {rooms.map((room) => (
            <div
              key={room.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
            >
              <div className="relative">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-semibold">{room.rating}</span>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{room.name}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {room.guests} Guests
                      </div>
                      <div>{room.size}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-amber-600">{room.price}</div>
                    <div className="text-sm text-gray-500">per night</div>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-6 leading-relaxed">{room.description}</p>
                
                <div className="grid grid-cols-2 gap-2 mb-6">
                  {room.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-600">
                      <div className="w-2 h-2 bg-amber-600 rounded-full mr-2"></div>
                      {amenity}
                    </div>
                  ))}
                </div>
                
                <div className="flex space-x-3">
                  <button 
                    className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-3 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 font-semibold flex items-center justify-center"
                    onClick={() => setSelectedRoom(room.id)}
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    Book Now
                  </button>
                  <button className="px-6 py-3 border-2 border-amber-600 text-amber-600 rounded-lg hover:bg-amber-600 hover:text-white transition-all duration-200 font-semibold">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Booking Modal */}
        {selectedRoom && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-8 max-w-md w-full">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Book Your Room</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Check In</label>
                  <input type="date" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Check Out</label>
                  <input type="date" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Guests</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500">
                    <option>1 Guest</option>
                    <option>2 Guests</option>
                    <option>3 Guests</option>
                    <option>4+ Guests</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input type="tel" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500" />
                </div>
              </div>
              <div className="flex space-x-3 mt-6">
                <button 
                  className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-3 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 font-semibold"
                >
                  Confirm Booking
                </button>
                <button 
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-200"
                  onClick={() => setSelectedRoom(null)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Rooms;
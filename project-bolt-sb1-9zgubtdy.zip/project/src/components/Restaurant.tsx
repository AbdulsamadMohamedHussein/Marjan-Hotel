import React, { useState } from 'react';
import { ShoppingCart, Plus, Minus, Star, Clock, Users } from 'lucide-react';

const Restaurant: React.FC = () => {
  const [cart, setCart] = useState<{[key: number]: number}>({});
  const [selectedCategory, setSelectedCategory] = useState('main');

  const categories = [
    { id: 'main', name: 'Main Dishes', icon: '🍽️' },
    { id: 'appetizers', name: 'Appetizers', icon: '🥗' },
    { id: 'beverages', name: 'Beverages', icon: '🥤' },
    { id: 'desserts', name: 'Desserts', icon: '🍰' }
  ];

  const menuItems = {
    main: [
      {
        id: 1,
        name: "Nyama Choma",
        description: "Traditional Kenyan grilled meat served with ugali and sukuma wiki",
        price: 1200,
        image: "https://images.pexels.com/photos/1639562/pexels-photo-1639562.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.8,
        prepTime: "25 mins",
        spicy: true
      },
      {
        id: 2,
        name: "Pilau Rice",
        description: "Aromatic spiced rice cooked with tender beef and traditional Kenyan spices",
        price: 800,
        image: "https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.7,
        prepTime: "30 mins",
        spicy: false
      },
      {
        id: 3,
        name: "Fish Curry",
        description: "Fresh Tana River fish in coconut curry sauce with chapati",
        price: 1000,
        image: "https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.9,
        prepTime: "20 mins",
        spicy: true
      },
      {
        id: 4,
        name: "Githeri Special",
        description: "Traditional mix of maize and beans with vegetables and meat",
        price: 600,
        image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.6,
        prepTime: "15 mins",
        spicy: false
      }
    ],
    appetizers: [
      {
        id: 5,
        name: "Samosas",
        description: "Crispy pastries filled with spiced meat and vegetables",
        price: 200,
        image: "https://images.pexels.com/photos/5560763/pexels-photo-5560763.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.5,
        prepTime: "10 mins",
        spicy: true
      },
      {
        id: 6,
        name: "Bhajias",
        description: "Deep-fried potato fritters with tamarind chutney",
        price: 300,
        image: "https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.4,
        prepTime: "12 mins",
        spicy: false
      }
    ],
    beverages: [
      {
        id: 7,
        name: "Kenyan Tea (Chai)",
        description: "Traditional spiced tea with milk and sugar",
        price: 150,
        image: "https://images.pexels.com/photos/1638280/pexels-photo-1638280.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.8,
        prepTime: "5 mins",
        spicy: false
      },
      {
        id: 8,
        name: "Fresh Passion Juice",
        description: "Locally sourced passion fruit juice",
        price: 250,
        image: "https://images.pexels.com/photos/1337825/pexels-photo-1337825.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.7,
        prepTime: "3 mins",
        spicy: false
      }
    ],
    desserts: [
      {
        id: 9,
        name: "Mandazi",
        description: "Sweet fried bread, perfect with tea or coffee",
        price: 100,
        image: "https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=1",
        rating: 4.6,
        prepTime: "8 mins",
        spicy: false
      }
    ]
  };

  const addToCart = (itemId: number) => {
    setCart(prev => ({
      ...prev,
      [itemId]: (prev[itemId] || 0) + 1
    }));
  };

  const removeFromCart = (itemId: number) => {
    setCart(prev => ({
      ...prev,
      [itemId]: Math.max((prev[itemId] || 0) - 1, 0)
    }));
  };

  const getTotalItems = () => {
    return Object.values(cart).reduce((sum, count) => sum + count, 0);
  };

  const getTotalPrice = () => {
    let total = 0;
    Object.entries(cart).forEach(([itemId, count]) => {
      const item = Object.values(menuItems).flat().find(item => item.id === parseInt(itemId));
      if (item) {
        total += item.price * count;
      }
    });
    return total;
  };

  return (
    <section id="restaurant" className="py-20 bg-gradient-to-br from-orange-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Authentic Kenyan Cuisine
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Savor the rich flavors of traditional Kenyan dishes prepared by our expert chefs 
            using fresh, local ingredients from the Tana River region.
          </p>
        </div>

        {/* Category Navigation */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-200 flex items-center space-x-2 ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-amber-100'
              }`}
            >
              <span>{category.icon}</span>
              <span>{category.name}</span>
            </button>
          ))}
        </div>

        {/* Menu Items */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {menuItems[selectedCategory as keyof typeof menuItems].map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
            >
              <div className="relative">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm font-semibold">{item.rating}</span>
                </div>
                {item.spicy && (
                  <div className="absolute top-4 right-4 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                    🌶️ Spicy
                  </div>
                )}
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{item.name}</h3>
                <p className="text-gray-600 mb-4 leading-relaxed">{item.description}</p>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {item.prepTime}
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-amber-600">
                    KSh {item.price.toLocaleString()}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300 transition-colors"
                      disabled={!cart[item.id]}
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center font-semibold">
                      {cart[item.id] || 0}
                    </span>
                    <button
                      onClick={() => addToCart(item.id)}
                      className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center hover:bg-amber-700 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <button
                    onClick={() => addToCart(item.id)}
                    className="bg-gradient-to-r from-amber-600 to-orange-600 text-white px-4 py-2 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 font-semibold"
                  >
                    Add to Order
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Cart Summary */}
        {getTotalItems() > 0 && (
          <div className="fixed bottom-4 right-4 bg-white rounded-2xl shadow-2xl p-6 max-w-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">Your Order</h3>
              <div className="flex items-center space-x-1">
                <ShoppingCart className="w-5 h-5 text-amber-600" />
                <span className="font-semibold">{getTotalItems()}</span>
              </div>
            </div>
            <div className="text-2xl font-bold text-amber-600 mb-4">
              Total: KSh {getTotalPrice().toLocaleString()}
            </div>
            <button className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-3 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 font-semibold">
              Place Order
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default Restaurant;